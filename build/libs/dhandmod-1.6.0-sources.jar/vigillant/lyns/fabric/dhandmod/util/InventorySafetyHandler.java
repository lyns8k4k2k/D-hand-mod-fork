package vigillant.lyns.fabric.dhandmod.util;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_490;
import java.util.Random;

public class InventorySafetyHandler {
    private static boolean inventoryActionInProgress = false;
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static final Random random = new Random();

    public static void onInventoryKeyPressed() {
        if (inventoryActionInProgress) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        int targetSlot = -1;

        // Find totem in hotbar
        for (int i = 0; i < 9; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8288) {
                targetSlot = i;
                break;
            }
        }

        // Switch slot (uses access widener)
        if (targetSlot != -1 && client.field_1724.method_31548().field_7545 != targetSlot) {
            client.field_1724.method_31548().field_7545 = targetSlot;
        }

        long delayMs = 15 + random.nextInt(25);
        inventoryActionInProgress = true;

        scheduler.schedule(() -> {
            client.execute(() -> {
                try {
                    if (client.field_1724 != null && client.field_1755 == null) {
                        client.method_1507(new class_490(client.field_1724));
                    }
                } finally {
                    inventoryActionInProgress = false;
                }
            });
        }, delayMs, TimeUnit.MILLISECONDS);
    }

    public static void shutdown() {
        scheduler.shutdown();
    }
}