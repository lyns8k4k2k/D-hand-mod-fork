package vigillant.lyns.fabric.dhandmod.util;

import net.minecraft.class_310;

public interface MC {
    default class_310 getMc() {
        return class_310.method_1551();
    }
}
