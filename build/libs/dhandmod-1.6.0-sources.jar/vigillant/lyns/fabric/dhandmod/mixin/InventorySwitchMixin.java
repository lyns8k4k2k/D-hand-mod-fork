package vigillant.lyns.fabric.dhandmod.mixin;

import net.minecraft.class_304;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import vigillant.lyns.fabric.dhandmod.util.InventorySafetyHandler;

@Mixin(class_310.class)
public abstract class InventorySwitchMixin {
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onHandleInputEvents(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_304 inventoryKey = client.field_1690.field_1822;

        // Use wasPressed() instead of isPressed() to avoid repeated triggering
        if (inventoryKey.method_1436() && client.field_1755 == null) {
            InventorySafetyHandler.onInventoryKeyPressed();
        }
    }
}